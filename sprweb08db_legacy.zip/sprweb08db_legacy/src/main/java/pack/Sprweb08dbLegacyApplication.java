package pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprweb08dbLegacyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sprweb08dbLegacyApplication.class, args);
	}

}

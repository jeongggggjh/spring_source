package pack.model;

import lombok.Data;

@Data
public class SangpumDto {
	private String code, sang, su, dan;
}

package pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprweb07thApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sprweb07thApplication.class, args);
	}

}

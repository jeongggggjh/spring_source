package pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprweb07thApplicationTests {

	@Test
	void contextLoads() {
	}

}
